rootProject.name = "codeclub-discordbot"
